# ReForge AI

Web reference-guided character replacement menggunakan Cloudflare Workers AI + `@cf/black-forest-labs/flux-2-klein-4b`.

## Fitur

- Upload gambar referensi utama.
- Upload gambar orang/render/skinsheet sebagai karakter pengganti.
- Mode Orang / Render dan Skinsheet.
- Pengaturan seberapa ketat scene referensi dipertahankan.
- Instruksi tambahan opsional.
- Preview, regenerate, dan simpan hasil.
- API key/credential tidak pernah ditaruh di frontend.
- Frontend bisa di-host gratis di GitHub Pages.
- Backend bisa di-host di Cloudflare Worker dengan Workers AI binding.

## 1. Deploy backend Cloudflare Worker

Syarat: Node.js terpasang dan punya akun Cloudflare.

```bash
cd worker
npx wrangler login
npx wrangler deploy
```

Setelah deploy, Wrangler akan memberi URL seperti:

```text
https://reforge-ai-api.NAMA-SUBDOMAIN.workers.dev
```

Endpoint API-nya:

```text
https://reforge-ai-api.NAMA-SUBDOMAIN.workers.dev/api/generate
```

## 2. Atur frontend

Buka `config.js` lalu ganti:

```js
window.REFORGE_CONFIG = {
  API_URL: "https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev/api/generate"
};
```

menjadi URL Worker milikmu.

## 3. Kunci CORS untuk production

Setelah GitHub Pages aktif, ubah `worker/wrangler.toml`:

```toml
[vars]
ALLOWED_ORIGIN = "https://USERNAME.github.io"
```

Jika project Pages berada pada custom domain, gunakan origin custom domain itu.

Lalu deploy ulang:

```bash
cd worker
npx wrangler deploy
```

## 4. Deploy frontend ke GitHub Pages

1. Buat repository GitHub baru.
2. Upload `index.html`, `styles.css`, `app.js`, dan `config.js` ke root repo.
3. Masuk ke **Settings → Pages**.
4. Pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/ (root)`.
6. Simpan.

## Kenapa gambar diperkecil sebelum dikirim?

FLUX.2 Klein 4B pada Workers AI mendukung multi-reference, tetapi input image harus berukuran di bawah 512×512. Frontend otomatis membuat salinan maksimum 500 px untuk request AI; file asli user tidak diubah.

## Catatan kualitas

Model generatif tidak menjamin background/efek tetap pixel-perfect. Prompt backend dibuat sangat ketat untuk memprioritaskan scene referensi, tetapi detail kecil masih dapat berubah. Untuk kasus yang membutuhkan penggantian area yang benar-benar terkunci, pendekatan berikutnya adalah menambahkan segmentation/mask + pipeline inpainting khusus.

## Privasi

Frontend tidak menyimpan gambar ke database. Gambar dikirim ke Worker hanya ketika user menekan Generate. Jika nanti kamu menambahkan storage/history, buat kebijakan privasi dan mekanisme penghapusan yang jelas.
